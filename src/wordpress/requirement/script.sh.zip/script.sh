#!/bin/bash

/usr/sbin/php-fpm7.3 -F -R